const mongoose = require("mongoose")
const Schema = mongoose.Schema

const products_schema = new Schema({
    // imagePath: {
    //     type: String,
    //     required: true,
    //     trim:true
    // },
    title: {
        type: String,
        required: true,
        trim:true
    },
    Water_distribution_Time: {
        type: String,
        required: true,
        trim:true
    },
        Water_Level: {
        type: String,
        trim:true,
        required: true,
    },
    Water_distribution_duration: {
        type: String,
        trim:true,
        required: true,
    },
    Water_distribution_area: {
        type: String,
        trim:true,
        required: true,
    },
    Updating_Date: {
        type: String,
        required: true,
        trim:true
    },
    category:{
        type:String,
        required:true,
        trim:true
    },
    is_deleted:{
        type:Boolean,
        required:true,
        default:false
    }
    

})

module.exports = {
    product:mongoose.model("product", products_schema)
}
